<?php
// Text
$_['text_title']       = 'Country Zone Rate';
$_['text_description'] = 'Country Zone Shipping Rate';
?>